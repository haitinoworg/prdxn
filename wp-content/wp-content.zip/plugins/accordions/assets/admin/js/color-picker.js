	jQuery(document).ready(function(jQuery)
		{	


			jQuery(' .accordions_color').wpColorPicker();
					
					


		});