<?php

/*
* @Author 		pickplugins
* Copyright: 	2015 pickplugins
*/

if ( ! defined('ABSPATH')) exit;  // if direct access 
		
		

			$accordions_class = 'accordions';
			
			$html.= '<script>jQuery(document).ready(function($){$("#accordions-'.$post_id.'.accordions").accordion({active: "",event: "click",collapsible: '.$accordions_collapsible.',heightStyle: "'.$accordions_heightStyle.'",animated: "swing",})})</script>';



		
		
		
		
		
		
		
		
		
		



		
		
		
		
		
		
		