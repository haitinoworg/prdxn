<div>
<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'mojo-staging' ), admin_url( 'admin.php' ) ) );?>">
	<img style="width: 100%;" src="<?php echo MM_ASSETS_URL . 'img/dashboard-staging-widget.jpg'; ?>" />
</a>
</div>
